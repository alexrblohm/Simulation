random_letters2 <-
function(){
  sample(LETTERS, 1)
}
